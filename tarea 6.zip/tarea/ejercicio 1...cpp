#include <stdio.h>

main()
{
	int suma,numero,contador;
	suma=0; numero=1; contador=0;
	contador=0;
	while (contador<20)
	{
		if((numero%2)==0)
		{
		suma= suma+numero;
		contador=contador+1;
		}
		numero=numero+1;	
	}
	
	printf("\n la suma de los primeros 20 numeros pares es:%i",suma);
}
