#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include<time.h>

int main ()
{
	int opcion;

	do{
		
		printf("opcion 1. ejercicio 1\n");
		printf("opcion 2. ejercicio 2\n");
		printf("opcion 3. ejercicio 3\n");
		printf("opcion 4. ejercicio 4\n");
		printf("opcion 5. salir\n");
		printf("elige una opcion");
		scanf("%d",&opcion);
		switch(opcion){
			case 1:
				system("cls");
				printf("seleccionaste %i\n",opcion);
				
            
	             int suma,numero,contador;
	             suma=0; numero=1; contador=0;
	             contador=0;
	             while (contador<20)
	             {
		          if((numero%2)==0)
		           {
		            suma= suma+numero;
		            contador=contador+1;
		           }
		          numero=numero+1;	
	             }
	
	             printf("\n la suma de los primeros 20 numeros pares es:%i",suma);
	        
            break;
            ;
			case 2:
				system("cls");
				printf("seleccionaste %i\n",opcion);
               {
	             int fact=0;
	             printf("escribe el n�mero a calcular en factorial");
	             scanf("%d",&fact);
	             int temp=fact-1;
	             int r=fact;
	             while (temp>=1)
	             {
		           r=r*temp;
		           temp--;
	             }
	             printf("\n el factorial de %d es: %d",fact,r);
	             getch();
               }
			break;
			case 3:system("cls");
				printf("seleccionaste %i\n",opcion);
				{
	             int p;
	             int fila1[3]={2,3,2};
	             int fila2[5]={3,4,5,4,3};
	             int fila3[7]={4,5,6,7,6,5,4};
	             int fila4[9]={5,6,7,8,9,8,7,6,5};
	             printf("\n\t ");
	             printf("1");
	             printf("\n\t ");
	             for(p=0;p<3; p++)
	             {
		           printf("%i",fila1[p]);
	             }
	             printf("\n\t ");
	             for(p=0; p<5; p++)
	             {
		           printf("%i",fila2[p]);
	             }
	             printf("\n\t ");
	             for(p=0; p<7; p++)
	             {
		           printf("%i",fila3[p]);
	             }
	             printf("\n\t ");
	             for(p=0; p<9; p++)
	             {
		           printf("%i",fila4[p]);
	             }
                }
			break;
			case 4:
				printf("seleccionaste %i\n",opcion);
				{
                float importeCompra,descuento;
                int num, pctDescuento;
                srand(time(NULL));
                num=rand() % 8; // rango de valores
                printf ("\n----------------------------------------------------");
                switch(num)
                {
                case 0:
                printf ("\nBolita de color negro");
                descuento=10;
                break;
                case 1: printf ("\nBolita de color verde"); descuento=25;
                break;
                case 2: printf ("\nBolita de color amarillo"); descuento=50;
                break;
                case 3: printf ("\nBolita de color azul"); descuento=75;
                break;
                case 4: printf ("\nBolita de color rojo"); descuento=100;
                break;
                default:
                descuento=0;
                printf ("\n Sin descuento");
                }
                printf ("\n\nSu descuento es de %f porciento", descuento);
                printf ("\n----------------------------------------------------");
                printf ("\nImporte total de la compra (sin descuento): $ ");
                scanf ("%4.2f", &importeCompra);
                descuento = importeCompra * ( 1 - descuento / 100);
                printf ("\nSu importe total de compra fue: %4.2f", importeCompra);
                printf ("\nEl importe total con el descuento ser� de: $ %.2f \n\n", descuento);
                return 1;
                }
			break;
			case 5:
				printf("seleccionaste %i\n",opcion);
			break;
			default:
			break;
			printf("opcion incorrecta\n");
		}
			
	}while(opcion !=6);
	
}
