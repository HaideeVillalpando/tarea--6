#include <stdio.h>
#include <conio.h>

int main()
{
	int fact=0;
	printf("escribe el n�mero a calcular en factorial");
	scanf("%d",&fact);
	int temp=fact-1;
	int r=fact;
	while (temp>=1)
	{
		r=r*temp;
		temp--;
	}
	printf("\n el factorial de %d es: %d",fact,r);
	getch();
}
