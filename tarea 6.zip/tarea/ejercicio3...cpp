#include<stdio.h>

main()
{
	int p;
	int fila1[3]={2,3,2};
	int fila2[5]={3,4,5,4,3};
	int fila3[7]={4,5,6,7,6,5,4};
	int fila4[9]={5,6,7,8,9,8,7,6,5};
	printf("\n\t ");
	printf("1");
	printf("\n\t ");
	for(p=0;p<3; p++)
	{
		printf("%i",fila1[p]);
	}
	printf("\n\t ");
	for(p=0; p<5; p++)
	{
		printf("%i",fila2[p]);
	}
	printf("\n\t ");
	for(p=0; p<7; p++)
	{
		printf("%i",fila3[p]);
	}
	printf("\n\t ");
	for(p=0; p<9; p++)
	{
		printf("%i",fila4[p]);
	}


}
